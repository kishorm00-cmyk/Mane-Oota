Mane Oota – Android App (Starter)

App name: Mane Oota
Package: com.jnana.tiffin

## To build a debug APK (local)
1. Open in Android Studio (Giraffe or newer).
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. Or run: `./gradlew assembleDebug`
4. APK path: `app/build/outputs/apk/debug/app-debug.apk`

I cannot build the APK inside this environment because Android SDK and build tools are not available here.
If you want CI to build automatically, add the provided GitHub Actions workflow to your repo and run it.